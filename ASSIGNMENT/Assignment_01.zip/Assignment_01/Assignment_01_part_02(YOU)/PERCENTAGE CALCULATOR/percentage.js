var subject_1 = 73, subject_2 = 85, subject_3 = 62;
var percentage;
percentage = (subject_1 + subject_2 + subject_3) * 100 / 300;
console.log("Percentage is : ", percentage);