/*
Given the name of the cricketers and qualities/achievments, 
create a variable (in camel case) as the name of the person 
and assign the value matching to it.
*/

var viratKohli="The Angry Young Man";
var mahenderSinghDhoni ="Captain Cool";
var yuvrajSingh ="Six Sixes";
var sachinRameshTendulkar ="The Master Blaster";
var rahulSharadDravid ="The Wall";
var abrahamBenjaminDeVilliers ="360 Degrees";
var lasithMalinga ="Yorker Specialist";
var shoaibAkhatar ="Fastest Ball Ever";
var ShaneWarne = "Ball of the Century";

console.log("\nVirat Kohli: ", viratKohli);
console.log("Mahender Singh Dhoni: ", mahenderSinghDhoni);
console.log("Yuvraj Singh: ", yuvrajSingh);
console.log("Sachin Ramesh Tendulkar: ", sachinRameshTendulkar);
console.log("Rahul Sharad Dravid: ", rahulSharadDravid);
console.log("Abraham Benjamin De Villiers: ", abrahamBenjaminDeVilliers);
console.log("Lasith Malinga: ", lasithMalinga);
console.log("Shoaib Akhatar: ", shoaibAkhatar);
console.log("Shane Warne: ", ShaneWarne);