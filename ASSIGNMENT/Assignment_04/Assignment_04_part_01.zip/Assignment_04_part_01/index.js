/*
What 
is
Lorem 
Ipsum?
*/
var myText = "Lorem Ipsum";

console.log(myText);