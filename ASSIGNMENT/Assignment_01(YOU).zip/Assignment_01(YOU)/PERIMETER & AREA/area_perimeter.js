var length = 17, breath = 10, area, perimeter;
area = length * breath;
perimeter = 2 * (length + breath);
console.log("Area of rectangular : ", area);
console.log("perimeter of rectangular : ", perimeter);