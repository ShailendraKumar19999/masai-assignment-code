
// typeof 1729 -> number
console.log(typeof 1729);

// typeof "Masai School" -> string
console.log(typeof "Masai School");

// typeof false -> boolean
console.log(typeof false);

// typeof "" ->string
console.log(typeof "");

// typeof undefined -> undefined
console.log(typeof undefined);