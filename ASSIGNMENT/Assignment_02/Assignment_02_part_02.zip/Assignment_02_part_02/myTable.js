var myTable = 13;
for (var i = 1; i < 11; i++){
    
    console.log(myTable*i);
}