var myNum = 7;
if (myNum >= 6 && myNum <= 10) {
    console.log("The number is between 6 and 10");
}
if (myNum > 5) {
    console.log("The number is greater than 5");
}
if (myNum <= 12) {
    console.log("The number is less than or equal to  12");
}
if (myNum % 7 === 0) {
    console.log("The number is divisible by 7");
}