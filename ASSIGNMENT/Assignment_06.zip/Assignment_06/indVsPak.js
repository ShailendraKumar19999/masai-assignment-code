var indiaScore = 200;
var pakScore = 250;

if (indiaScore > pakScore) {
    console.log("India wins");
}
else if (indiaScore === pakScore) {
    console.log("Match Tied");
}
else  {
    console.log("Pakistan wins");
}